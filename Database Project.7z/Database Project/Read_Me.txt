Java based "Oracle Sqlplus runner" version 1.0 is available here. Please use and test

Just click the Login.jar file in the "Database Project" folder to execute. 

* In first phase it basically designed for searching operations.
* You should have Oracle sqlplus installed, any account with table name and details can be shown by the app.
* Don't use semicolon(";") while writting the sql command. It will be automaticaly added after your sql query.
* After all query close the application dont need to log off.

